performance: 5.120 MPKI


On top of GShare:
Using take, mixing coorelation base predictor with age.